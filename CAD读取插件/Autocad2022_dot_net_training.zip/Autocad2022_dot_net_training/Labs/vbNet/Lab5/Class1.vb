﻿' (C) Copyright 2002-2005 by Autodesk, Inc. 
'
' Permission to use, copy, modify, and distribute this software in
' object code form for any purpose and without fee is hereby granted, 
' provided that the above copyright notice appears in all copies and 
' that both that copyright notice and the limited warranty and
' restricted rights notice below appear in all supporting 
' documentation.
'
' AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS. 
' AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
' MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.  AUTODESK, INC. 
' DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
' UNINTERRUPTED OR ERROR FREE.
'
' Use, duplication, or disclosure by the U.S. Government is subject to 
' restrictions set forth in FAR 52.227-19 (Commercial Computer
' Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
' (Rights in Technical Data and Computer Software), as applicable.
'

Imports Autodesk.AutoCAD.Runtime
Imports Autodesk.AutoCAD.ApplicationServices
Imports Autodesk.AutoCAD.EditorInput
Imports Autodesk.AutoCAD.DatabaseServices
Imports Autodesk.AutoCAD.Geometry
Imports System.Windows

Imports Autodesk.AutoCAD.Windows

Public Class adskClass

    ' Define command 'helloworld'
    <CommandMethod("helloworld")> _
    Public Sub helloworld()

        ' get the editor object
        Dim ed As Autodesk.AutoCAD.EditorInput.Editor = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument.Editor
        ' now write to the command line
        ed.WriteMessage(vbCr + "Hello World")

    End Sub

    <CommandMethod("addAnEnt")> _
    Public Sub AddAnEnt()

        ' get the editor object so we can carry out some input
        Dim ed As Editor = Application.DocumentManager.MdiActiveDocument.Editor

        ' first decide what type of entity we want to create
        Dim getWhichEntityOptions As PromptKeywordOptions = New PromptKeywordOptions("Which entity do you want to create? [Circle/Block] : ", "Circle Block")
        ' now input it
        Dim getWhichEntityResult As PromptResult = ed.GetKeywords(getWhichEntityOptions)
        ' if ok
        If (getWhichEntityResult.Status = PromptStatus.OK) Then

            ' test which one is required
            Select Case getWhichEntityResult.StringResult

                Case "Circle"

                    ' pick the center point of the circle
                    Dim getPointOptions As PromptPointOptions = New PromptPointOptions("Pick Center Point : ")
                    Dim getPointResult As PromptPointResult = ed.GetPoint(getPointOptions)
                    ' if ok
                    If (getPointResult.Status = PromptStatus.OK) Then

                        ' the get the radius
                        Dim getRadiusOptions As PromptDistanceOptions = New PromptDistanceOptions("Pick Radius : ")
                        ' set the start point to the center (the point we just picked)
                        getRadiusOptions.BasePoint = getPointResult.Value
                        ' now tell the input mechanism to actually use the basepoint!
                        getRadiusOptions.UseBasePoint = True
                        ' now get the radius
                        Dim getRadiusResult As PromptDoubleResult = ed.GetDistance(getRadiusOptions)
                        ' if all is ok
                        If (getRadiusResult.Status = PromptStatus.OK) Then

                            ' need to add the circle to the current space
                            ' get the current working database
                            Dim dwg As Database = ed.Document.Database
                            ' now start a transaction
                            Dim trans As Transaction = dwg.TransactionManager.StartTransaction()
                            Try

                                ' create a new circle
                                Dim circle As New Circle(getPointResult.Value, Vector3d.ZAxis, getRadiusResult.Value)
                                ' open the current space (block table record) for write
                                Dim btr As BlockTableRecord = trans.GetObject(dwg.CurrentSpaceId, OpenMode.ForWrite)
                                ' now the circle to the current space, model space more than likely
                                btr.AppendEntity(circle)
                                ' tell the transaction about the new circle so that it can autoclose it
                                trans.AddNewlyCreatedDBObject(circle, True)
                                ' now commit the transaction
                                trans.Commit()

                            Catch ex As Exception
                                ' ok so we have an exception
                                ed.WriteMessage("problem due to " + ex.Message)
                            Finally
                                ' all done, whether an error on not - dispose the transaction.
                                trans.Dispose()
                            End Try

                        End If
                    End If

                Case "Block"

                    ' enter the name of the block
                    Dim blockNameOptions As PromptStringOptions = New PromptStringOptions("Enter name of the Block to create : ")
                    ' no spaces are allowed in a blockname so disable it
                    blockNameOptions.AllowSpaces = False
                    ' get the name
                    Dim blockNameResult As PromptResult = ed.GetString(blockNameOptions)
                    ' if ok
                    If (blockNameResult.Status = PromptStatus.OK) Then

                        ' lets create the block definition
                        ' get the current drawing
                        Dim dwg As Database = ed.Document.Database
                        ' now start a transaction
                        Dim trans As Transaction = dwg.TransactionManager.StartTransaction
                        Try

                            ' create the new block definition
                            Dim newBlockDef As BlockTableRecord = New BlockTableRecord
                            ' name the block definition
                            newBlockDef.Name = blockNameResult.StringResult

                            ' now add the new block defintion to the block table
                            ' open the blok table for read so we can check to see if the name already exists
                            Dim blockTable As BlockTable = trans.GetObject(dwg.BlockTableId, OpenMode.ForRead)
                            ' check to see if the block already exists
                            If (blockTable.Has(blockNameResult.StringResult) = False) Then
                                ' if it's not there, then we are ok to add it
                                ' but first we need to upgrade the open to write
                                blockTable.UpgradeOpen()
                                blockTable.Add(newBlockDef)
                                ' tell the transaction manager about the new object so that the transaction will autoclose it
                                trans.AddNewlyCreatedDBObject(newBlockDef, True)
                            End If

                            ' now add some objects to the block definition
                            Dim circle1 As New Circle(New Point3d(0, 0, 0), Vector3d.ZAxis, 10)
                            Dim circle2 As New Circle(New Point3d(20, 10, 0), Vector3d.ZAxis, 10)
                            Dim circle3 As New Circle(New Point3d(40, 20, 0), Vector3d.ZAxis, 10)
                            Dim circle4 As New Circle(New Point3d(60, 30, 0), Vector3d.ZAxis, 10)
                            Dim circle5 As New Circle(New Point3d(80, 40, 0), Vector3d.ZAxis, 10)
                            newBlockDef.AppendEntity(circle1)
                            newBlockDef.AppendEntity(circle2)
                            newBlockDef.AppendEntity(circle3)
                            newBlockDef.AppendEntity(circle4)
                            newBlockDef.AppendEntity(circle5)
                            ' tell the transaction manager about the new objects so that the transaction will autoclose it
                            trans.AddNewlyCreatedDBObject(circle1, True)
                            trans.AddNewlyCreatedDBObject(circle2, True)
                            trans.AddNewlyCreatedDBObject(circle3, True)
                            trans.AddNewlyCreatedDBObject(circle4, True)
                            trans.AddNewlyCreatedDBObject(circle5, True)

                            ' now set where it should appear in the current space
                            Dim blockRefPointOptions As PromptPointOptions = New PromptPointOptions("Pick insertion point of Block : ")
                            Dim blockRefPointResult As PromptPointResult = ed.GetPoint(blockRefPointOptions)
                            ' check to see if everything was ok - if not
                            If (blockRefPointResult.Status <> PromptStatus.OK) Then
                                ' dispose of everything that we have done so far and return
                                trans.Dispose()
                                Return
                            End If
                            ' now we have the block defintion in place and the position we need to create the reference to it
                            Dim blockRef As BlockReference = New BlockReference(blockRefPointResult.Value, newBlockDef.ObjectId)
                            ' otherwise add it to the current space, first open the current space for write
                            Dim curSpace As BlockTableRecord = trans.GetObject(dwg.CurrentSpaceId, OpenMode.ForWrite)
                            ' now add the block reference to it
                            curSpace.AppendEntity(blockRef)
                            ' remember to tell the transaction about the new block reference so that the transaction can autoclose it
                            trans.AddNewlyCreatedDBObject(blockRef, True)

                            ' all ok, commit it
                            trans.Commit()

                        Catch ex As Exception
                            ' a problem occured, lets print it
                            ed.WriteMessage("a problem occured because " + ex.Message)
                        Finally
                            ' whatever happens we must dispose the transaction
                            trans.Dispose()

                        End Try

                    End If

            End Select
        End If

    End Sub

    ' declare a paletteset object, this will only be created once
    Public myPaletteSet As Autodesk.AutoCAD.Windows.PaletteSet
    ' we need a palette which will be housed by the paletteSet
    Public myPalette As UserControl1

    ' palette command
    <CommandMethod("palette")> _
    Public Sub palette()

        ' check to see if it is valid
        If (myPaletteSet = Nothing) Then
            ' create a new palette set, with a unique guid
            myPaletteSet = New Autodesk.AutoCAD.Windows.PaletteSet("My Palette", New Guid("D61D0875-A507-4b73-8B5F-9266BEACD596"))
            ' now create a palette inside, this has our tree control
            myPalette = New UserControl1
            ' now add the palette to the paletteset
            myPaletteSet.Add("Palette1", myPalette)

        End If

        ' now display the paletteset
        myPaletteSet.Visible = True

    End Sub

    <CommandMethod("addDBEvents")> _
    Public Sub addDBEvents()

        ' the palette needs to be created for this
        If myPalette Is Nothing Then
            ' get the editor object
            Dim ed As Autodesk.AutoCAD.EditorInput.Editor = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument.Editor
            ' now write to the command line
            ed.WriteMessage(vbCr + "Please call the 'palette' command first")
            Exit Sub
        End If

        ' get the current working database
        Dim curDwg As Database = Application.DocumentManager.MdiActiveDocument.Database
        ' add a handlers for what we need
        AddHandler curDwg.ObjectAppended, New ObjectEventHandler(AddressOf callback_ObjectAppended)
        AddHandler curDwg.ObjectErased, New ObjectErasedEventHandler(AddressOf callback_ObjectErased)
        AddHandler curDwg.ObjectReappended, New ObjectEventHandler(AddressOf callback_ObjectReappended)
        AddHandler curDwg.ObjectUnappended, New ObjectEventHandler(AddressOf callback_ObjectUnappended)

    End Sub

    Private Sub callback_ObjectAppended(ByVal sender As Object, ByVal e As ObjectEventArgs)

        ' add the class name of the object to the tree view
        Dim newNode As System.Windows.Forms.TreeNode = myPalette.TreeView1.Nodes.Add(e.DBObject.GetType().ToString())
        ' we need to record its id for recognition later
        newNode.Tag = e.DBObject.ObjectId.ToString()

    End Sub

    Private Sub callback_ObjectErased(ByVal sender As Object, ByVal e As ObjectErasedEventArgs)

        ' if the object was erased
        If e.Erased Then
            ' find the object in the treeview control so we can remove it
            For Each node As Forms.TreeNode In myPalette.TreeView1.Nodes
                ' is this the one we want
                If (node.Tag = e.DBObject.ObjectId.ToString) Then
                    node.Remove()
                    Exit For
                End If
            Next
            ' if the object was unerased
        Else
            ' add the class name of the object to the tree view
            Dim newNode As System.Windows.Forms.TreeNode = myPalette.TreeView1.Nodes.Add(e.DBObject.GetType().ToString())
            ' we need to record its id for recognition later
            newNode.Tag = e.DBObject.ObjectId.ToString()
        End If
    End Sub
    Private Sub callback_ObjectReappended(ByVal sender As Object, ByVal e As ObjectEventArgs)

        ' add the class name of the object to the tree view
        Dim newNode As Forms.TreeNode = myPalette.TreeView1.Nodes.Add(e.DBObject.GetType().ToString())
        ' we need to record its id for recognition later
        newNode.Tag = e.DBObject.ObjectId.ToString()

    End Sub

    Private Sub callback_ObjectUnappended(ByVal sender As Object, ByVal e As ObjectEventArgs)

        ' find the object in the treeview control so we can remove it
        For Each node As Forms.TreeNode In myPalette.TreeView1.Nodes
            ' is this the one we want
            If (node.Tag = e.DBObject.ObjectId.ToString) Then
                node.Remove()
                Exit For
            End If
        Next

    End Sub


    <CommandMethod("addData")> _
    Public Sub addData()

        ' get the editor object
        Dim ed As Editor = Application.DocumentManager.MdiActiveDocument.Editor
        ' pick entity to add data to!
        Dim getEntityResult As PromptEntityResult = ed.GetEntity("Pick an entity to add an Extension Dictionary to : ")
        ' if all was ok
        If (getEntityResult.Status = PromptStatus.OK) Then
            ' now start a transaction
            Dim trans As Transaction = ed.Document.Database.TransactionManager.StartTransaction
            Try

                ' Start of Lab5
                ' Here we will add XData to a selected entity.

                ' 1. Declare an Entity variable named ent. Instantiate it using
                ' GetOBject of the Transaction created above. (Trans) For the 
                ' ObjectId parameter use the ObjectId property of the the 
                ' PromptEntityResult created above.(getEntityResult) Open the entity for read.

                ' 2. Use an "If Then" statement and test the IsNull property of the
                ' ExtensionDictionary of the ent. If it is Null then we create 
                ' the ExtensionDictionary.
                ' Note: Place the "End If" after step 4.


                ' 3. Upgrade the open of the entity. Because it does 
                ' not have an extenstion dictionary and we want to add it
                ' the ent needs to be open for write.


                ' 4. Create the ExtensionDictionary by calling 
                ' CreateExtensionDictionary of the entity.


                ' 5. Declare a variable as DBDictionary. Instantiate it by using the 
                ' GetObject method of the Transaction created above. (trans). For the 
                ' ObjectId parameter use the ExtensionDictionary property of the ent
                ' created in step 1. Open it for read

                ' 6. Check to see if the entry we are going to add to the dictionary is 
                ' already there. Use the Contains property of the dictionary in an "If Else
                ' End If" statement.
                ' Note: put the "Else" after step 12 and the "End If" after step 25 


                ' 7. Declare an ObjectId variable instantiate it
                ' using the GetAt method of the ExtenstionDictionary from step 5. Use
                ' "MyData" for the entryName


                ' 8. If this line gets hit then data is already added 
                ' Use the WriteMessage method of the Editor (ed) created above
                ' to print the data. For the string argument use something like this:
                ' ControlChars.Lf + "This entity already has data..."

                ' 9. Now extract the Xrecord. Declare an Xrecord variable.

                ' 10. Instantiate the Xrecord variable using the 
                ' GetObject method of the Transaction created above. (trans).
                ' For the ObjectId argument use the ObjectId created in step 7
                ' open for read

                ' 11. Here print out the values in the Xrecord to the command line.
                ' Use a "For Each" statement. For the Element type use a TypedValue.
                ' (Use value for the name of the TypedValue) For the Group use the 
                ' Data property of the Xrecord
                ' Note: Put the Next statement below step 12

                ' 12. Use the WriteMessage method of the Editor created above. (ed).
                ' for the string argument use something like this:
                ' ControlChars.Lf + value.TypeCode.ToString() + " . " + value.Value.ToString()

                ' 13. If the code gets to here then the data entry does not exist
                ' upgrade the ExtensionDictionary created in step 5 to write by calling
                ' the UpgradeOpen() method


                ' 14. Create a new XRecord. Declare an Xrecord variable as a New Xrecord

                ' 15. Create the resbuf list. Declare a ResultBuffer variable. Instantiate it
                ' by creating a New ResultBuffer. For the ParamArray of TypeValue for the new
                ' ResultBuffer use the following:
                ' New TypedValue(DxfCode.Int16, 1), _
                ' New TypedValue(DxfCode.Text, "MyStockData"), _
                ' New TypedValue(DxfCode.Real, 51.9), _
                ' New TypedValue(DxfCode.Real, 100.0), _
                ' New TypedValue(DxfCode.Real, 320.6)


                ' 16. Add the ResultBuffer to the Xrecord using the Data
                ' property of the Xrecord. (make it equal the ResultBuffer
                ' from step 15)


                ' 17. Create the entry in the ExtensionDictionary. Use the SetAt
                ' method of the ExtensionDictionary from step 5. For the SearchKey
                ' argument use "MyData". For the DBObject argument use the Xrecord
                ' created in step 14.


                ' 18. Tell the transaction about the newly created Xrecord
                ' using the AddNewlyCreatedDBObject of the Transaction (trans)

                ' 19. Here we will populate the treeview control with the new data
                ' Use an "If Not Is Nothing Then" statement to check to see if the
                ' palette (myPalette created in Lab 4) has been started.
                ' (If not then it will crash)
                ' Note: Put the "End If" after step 25

                ' 20. Create a For Each statement. Use node for the element name and
                ' the type is Forms.Treenode. The group paramater is the Nodes in the
                ' TreeView.  (Me.myPalette.TreeView1.Nodes)
                ' Note: put the Next after step 25


                ' 21. Use an "If Then" statement. Test to see if the node Tag is the ObjectId
                ' of the ent from step 1. Use the ObjectId. (ent.ObjectId.ToString)
                ' Note: put the "End If" above the "Next" statement added in step 20

                ' 22. Now add the new data to the treenode. Declare a variable as a 
                ' Forms.Treenode. (name it something like childNode). Instantiate 
                ' it by making it equal to the return of calling the Add method
                ' of the Nodes collection of the node from the loop.
                ' (node.Nodes.Add) For the string argument use "Extension Dictionary"

                ' 23. Now add the data. Create a For Each statement. Use value for the element
                ' name and the type is TypedValue. The Data property of the Xrecord created in
                ' step 14.  
                ' Note: put the Next after step 24

                ' 24. Add the TypeValue from the For Each loop to the 
                ' TreeNode created in step 22. Use the Add method of the 
                ' Nodes Collection. (childNode.Nodes.Add) For the string
                ' argument use the TypeValue from the loop. (value.ToString)


                ' 25. Exit the for loop (all done - break out of the loop)


                ' all ok, commit it
                trans.Commit()

            Catch ex As Exception
                ' a problem occured, lets print it
                ed.WriteMessage("a problem occured because " + ex.Message)
            Finally
                ' whatever happens we must dispose the transaction
                trans.Dispose()

            End Try

        End If

    End Sub

    <CommandMethod("addDataToNOD")> _
    Public Sub addDataToNOD()

        ' get the editor object
        Dim ed As Editor = Application.DocumentManager.MdiActiveDocument.Editor

        Dim trans As Transaction = ed.Document.Database.TransactionManager.StartTransaction
        Try

            ' 26. Here we will add our data to the Named Objects Dictionary.(NOD)
            ' Declare a variable as a DBDictionary. (name it nod). Instantiate it
            ' by making it equal to the return of the GetObject method of the 
            ' Transaction created above. (trans). For the ObjectId argument use the 
            ' NamedObjectsDictionaryId property of the current Database:
            ' (ed.Document.Database.NamedObjectsDictionaryId) The Editor (ed) was
            ' instantiated above. Open it for read.


            ' 27. Check to see if the entry we are going to add to the dictionary is 
            ' already there. Use the Contains property of the dictionary in an "If Else
            ' End If" statement.
            ' Note: put the "Else" after step 33 and the "End If" after step 39 



            ' 28. Declare an ObjectId variable named entryId and instantiate it
            ' using the GetAt method of the ExtenstionDictionary from step 26. Use
            ' "MyData" for the entryName argument.


            ' 29. If we are here, then the Name Object Dictionary already has our data
            ' Use the WriteMessage method of the editor. Use this for the Message argument
            ' ControlChars.Lf + "This entity already has data..."


            ' 30. Get the the Xrecord from the NOD. Declare a variable as an Xrecord

            ' 31. USe the Transaction (trans) and use the GetObject method to 
            ' get the the Xrecord from the NOD. For the ObjectId argument use the
            ' ObjectId from step 28. Open the Xrecord for read

            ' 32. Print out the values of the Xrecord to the command line. Use
            ' a "For Each" statement. Use value for the element
            ' name and the type is TypedValue. Use the Data property of the Xrecord from 
            ' step 31 for the group argument
            ' Note: put the Next after step 33

            ' 33. Use the WriteMessage method of the editor. Use this as the message:
            ' ControlChars.Lf + value.TypeCode.ToString() + " . " + value.Value.ToString()


            ' 34. Our data is not in the Named Objects Dictionary so need to add it
            ' upgrade the status of the NOD variable from step 26 to write status

            ' 35. Declare a varable as a New Xrecord. 


            ' 36. Create the resbuf list. Declare a ResultBuffer variable. Instantiate it
            ' by creating a New ResultBuffer. For the ParamArray of TypeValue for the new
            ' ResultBuffer use the following:
            ' New TypedValue(DxfCode.Int16, 1), _
            ' New TypedValue(DxfCode.Text, "MyCompanyDefaultSettings"), _
            ' New TypedValue(DxfCode.Real, 51.9), _
            ' New TypedValue(DxfCode.Real, 100.0), _
            ' New TypedValue(DxfCode.Real, 320.6)


            ' 37. Add the ResultBuffer to the Xrecord using the Data
            ' property of the Xrecord. (make it equal the ResultBuffer
            ' from step 36)

            ' 38. Create the entry in the ExtensionDictionary. Use the SetAt
            ' method of the Named Objects Dictionary from step 26. For the SearchKey
            ' argument use "MyData". For the DBObject argument use the Xrecord
            ' created in step 35.


            ' 39. Tell the transaction about the newly created Xrecord
            ' using the AddNewlyCreatedDBObject of the Transaction (trans)



            ' all ok, commit it
            trans.Commit()

        Catch ex As Exception
            ' a problem occurred, lets print it
            ed.WriteMessage("a problem occurred because " + ex.Message)
        Finally
            ' whatever happens we must dispose the transaction
            trans.Dispose()

        End Try

    End Sub

End Class